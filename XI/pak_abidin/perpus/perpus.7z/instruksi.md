import db_perpus.sql ke phpmyadmin
jangan lupa rename database sebelum nya karena
bisa tabrakan, punya ku ada caps nya

bikin folder /pak_abidin/perpus/
unzip disitu semua akses lewat
localhost/pak_abidin/perpus/
