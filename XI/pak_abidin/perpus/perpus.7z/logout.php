<?php
include "lib/checklogin.php";
session_destroy();
header('location: perpus/login.php');
