<?php
include "lib/header.php";
?>
<h2>Selamat datang user <?php echo '"'.$_SESSION['nama_siswa'].'"'; ?> di website Perpus Online.</h2>
<?php
include "lib/footer.php";
?>